package com.example.digital.service;

import java.util.List;

import com.example.digital.entity.Contact;
import com.example.digital.entity.Course;
import com.example.digital.entity.Credential;
import com.example.digital.entity.Institution;
import com.example.digital.entity.Institution_User;
import com.example.digital.entity.Subject;

public interface IInstitutionService {

	Institution getInstitutionById(long institution_Id);

	Institution getContactById(Contact contact);

	Institution getParentInstitutionById(long Parent_Institution_Id);

	Institution_User getInstitution_UserById(long institution_User_Id);

	Institution getInstitutionByName(String institutionName);

	Institution_User getInstitutionUserByInstId(long institution_Id);

	Institution_User getInstitutionUserByUserId(long user_Id);

	Institution_User getInstitutionUserByContactId(long user_Id);

	Course getCourseByCourseId(long course_Id);

	List<Course> getAllCourse();

	boolean addCourse(Course course);

	void updateCourse(Course course);

	Subject getSubjectById(long subject_id);

	List<Subject> getAllSubject();

	boolean addSubject(Subject subject);

	void updateSubject(Subject subject);

	List<Institution> getAllInstitution();

	boolean addInstitution(Institution institution);

	Credential getCredentialById(long credential_Id);

	List<Credential> getAllCredential();

	boolean addCredential(Credential credential);

	
}
