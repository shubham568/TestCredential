package com.example.digital.repository;


import java.util.List;

import com.example.digital.entity.Address_Type;
import com.example.digital.entity.Contact;
import com.example.digital.entity.Contact_Address;


public interface IContactAddressDao {
	List<Contact_Address> getAllContact_Address();
	Contact_Address getContact_AddressByid(long Address_Id);
    void saveContact_Address(Contact_Address contact_address);
    void updateContact_Address(Contact_Address contact_address);
    //void deleteContact_Address(Contact_Address contact_address);
    boolean Contact_AddressExists(Contact contact, Address_Type address_Type,String Address_1,String Address_2,String Address_3,
    		String City,String State,String Country,long Postal_Code);
	//void updateContact_Address(Contact_Address contact_address, Contact contact);
}
