package com.example.digital.repository;

import java.time.Year;
import java.util.List;

import com.example.digital.entity.Course;
import com.example.digital.entity.Credential;
import com.example.digital.entity.Institution;

public interface ICredentialDAO {
	List<Credential> getAllCredentials();
	Credential getCredentialByid(long credential_Id);
    void addCredential(Credential credential);
    void updateCredential(Credential credential);
    //void deleteCredential(Credential credential);
	//boolean CredentialExists(String Credential_Name, String Credential_Year, Course course, Institution institution);
	boolean CredentialExists(long credential_Id, String credentialName, Year credentialYear, long course_Id,
			long institution_Id);
}
