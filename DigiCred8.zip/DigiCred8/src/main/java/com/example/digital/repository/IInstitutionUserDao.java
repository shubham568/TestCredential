package com.example.digital.repository;


import java.util.List;

import com.example.digital.entity.Institution_User;


public interface IInstitutionUserDao {

	List<Institution_User> getAllInstitution_Users();
	Institution_User getInstitution_UserByid(long institution_User_Id);
    void createInstitution_User(Institution_User institution_User);
    void updateInstitution_User(Institution_User institution_User);
	void deleteInstitution_User(long institution_UserByid);
	boolean institution_UserExists(long Institution_Id, long User_Id, long Contact_Id);
	
}
