package com.example.digital.entity;

public enum UserState {

	TRUE,FALSE
}
