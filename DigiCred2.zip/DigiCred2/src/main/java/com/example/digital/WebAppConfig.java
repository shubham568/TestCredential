package com.example.digital;

import org.springframework.beans.factory.annotation.Autowired;

import com.example.digital.service.LearnerService;
import com.example.digital.service.UserService;

//@Configuration
//@EnableWebSecurity
public class WebAppConfig/* extends WebSecurityConfigurerAdapter*/ {
	
	@Autowired
	private UserService userservice;
	
	@Autowired
	private LearnerService learnerService;
	
	
	/*
	
	@Bean
	@Override
	 public AuthenticationManager authenticationManagerBean() throws Exception {
	      return super.authenticationManagerBean();
	}  
	
	@Bean
	public IContactAddressDao ContactAddressDao() {
		return ContactAddressDao();
	}

	
	@Autowired
	private BCryptPasswordEncoder bCryptPasswordEncoder;
	
	
	 @Bean
	    public BCryptPasswordEncoder bCryptPasswordEncoder() {
		
	        return new  BCryptPasswordEncoder();
	    }
	 @Autowired
		@Qualifier("userDetailsService")
		private UserDetailsService userDetailsService;
		
		@Autowired
	    private DataSource dataSource;
		
		
		private final String USER_QUERY="select username,password,enable from user where username=?";
		private final String ROLES_QUERY="select * from user u inner join user_role ur on (u.userId=ur.User_Id)  inner join"
				+ "role r on (ur.role_Id=r.roleid where u.username=?)";
		
		@Autowired
		private AuthenticationManager authenticationManager;
		
		@Bean(name = BeanIds.AUTHENTICATION_MANAGER)
		   @Override
		   public AuthenticationManager authenticationManagerBean() throws Exception {
		       return super.authenticationManagerBean();
		   }
		
		@Bean
		public UserDetailsService userDetailsService() {
		    return super.userDetailsService();
		}
		
		
	 
	 @Autowired
	 public void configureGlobal(AuthenticationManagerBuilder auth,PasswordEncoder passwordEncoder) throws Exception {
		 System.out.println("**configure global");
	 auth.userDetailsService(userDetailsService);
	 auth.jdbcAuthentication()
	 .usersByUsernameQuery(USER_QUERY)
	 .authoritiesByUsernameQuery(ROLES_QUERY)
	 .dataSource(dataSource)
	 .passwordEncoder(bCryptPasswordEncoder);
	 }
*/	 }
