package com.example.digital.entity;

import java.io.Serializable;
import java.sql.*;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

@SuppressWarnings("serial")
@Entity
@Table(name="learner_credential")
public class Learner_Credential implements Serializable {

	public Learner_Credential() {
		super();
	}
	

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "Learner_Credential_Id", nullable = false, updatable = false)
	private long Learner_Credential_Id;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="Learner_id")
	@OnDelete(action = OnDeleteAction.CASCADE)
	private Learner learner;
	//@PrimaryKeyJoinColumn(name="Credential_Id",referencedColumnName="learners")
	@OneToOne(cascade = CascadeType.ALL)
	private Credential credential;
	@OneToOne(targetEntity = Grade.class, fetch = FetchType.EAGER)
	/*@JoinTable(name = "course_grade", joinColumns=@JoinColumn(name = "Course_Id"),
	inverseJoinColumns = @JoinColumn(name = "Grade_Id"))*/
	private Grade grade;
	@Column(name="Marks")
	private String Marks;
	@Column(name="Issued_date")
	private Date Issued_date;
	
	public long getLearner_Credential_Id() {
		return Learner_Credential_Id;
	}

	public void setLearner_Credential_Id(long learner_Credential_Id) {
		Learner_Credential_Id = learner_Credential_Id;
	}


	@JoinColumn(name="Course_Id")
	@OneToOne(targetEntity = Course.class, fetch = FetchType.EAGER)
	private Course course;
	
	
	
	/*@ManyToOne(targetEntity=Learner.class)
	//@JoinColumn(name="Learner_Id")
	@PrimaryKeyJoinColumn(name = "Learner_Credential_Id",referencedColumnName="Learner_id")
	   private Learner_Credential learnercredential;
	*/
	/*@JoinColumn(name="Learner_Credential_Id")
	@ManyToOne(targetEntity = Learner_Credential.class, fetch = FetchType.EAGER)
	private Learner_Credential_Resourse learnerCredentialResource;
	

	public long getLearner_Credential_Id() {
		return Learner_Credential_Id;
	}

	public void setLearner_Credential_Id(long learner_Credential_Id) {
		Learner_Credential_Id = learner_Credential_Id;
	}
*/
	public Learner getLearner() {
		return learner;
	}

	public void setLearner(Learner learner) {
		this.learner = learner;
	}

	public Credential getCredential() {
		return credential;
	}

	public void setCredential(Credential credential) {
		this.credential = credential;
	}

	public Grade getGrade() {
		return grade;
	}

	public void setGrade(Grade grade) {
		this.grade = grade;
	}

	public String getMarks() {
		return Marks;
	}

	public void setMarks(String marks) {
		Marks = marks;
	}

	public Date getIssued_date() {
		return Issued_date;
	}

	public void setIssued_date(Date issued_date) {
		Issued_date = issued_date;
	}

	public Course getCourse() {
		return course;
	}

	public void setCourse(Course course) {
		this.course = course;
	}

	@Override
	public String toString() {
		return "Learner_Credential [Learner_Credential_Id=" + Learner_Credential_Id + ", learner=" + learner.getLearnerId()
				+ ", credential=" + credential.getCredential_Id() + ", grade=" + grade.getGrade_Id() + ", Marks=" + Marks + ", Issued_date="
				+ Issued_date + ", course=" + course.getCourse_Id() + "]";
	}

}
