package com.example.digital.entity;

import java.io.Serializable;
import java.sql.*;
import java.time.Year;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@SuppressWarnings("serial")
@Entity
@Table(name="credential")
public class Credential implements Serializable {

	public Credential() {
		super();
	}

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "Credential_Id", nullable = false, updatable = false)
	private long Credential_Id;
	@Column(name="Credential_Name")
	private String credentialName;
	@Column(name="Credential_Year")
	private Year credentialYear;
	@JoinColumn(name="Course_Id")
	@ManyToOne(targetEntity = Course.class, fetch = FetchType.EAGER)
	private Course course;
	@JoinColumn(name="Institution_Id")
	@ManyToOne(targetEntity = Institution.class, fetch = FetchType.EAGER)
	private Institution institution;
	@Column(name="Issued_Date")
	private Date issuedDate;
	
	public long getCredential_Id() {
		return Credential_Id;
	}
	public void setCredential_Id(long credential_Id) {
		Credential_Id = credential_Id;
	}
	public String getCredentialName() {
		return credentialName;
	}
	public void setCredentialName(String credentialName) {
		this.credentialName = credentialName;
	}
	public Year getCredentialYear() {
		return credentialYear;
	}
	public void setCredentialYear(Year credentialYear) {
		this.credentialYear = credentialYear;
	}
	public Course getCourse() {
		return course;
	}
	public void setCourse(Course course) {
		this.course = course;
	}
	public Institution getInstitution() {
		return institution;
	}
	public void setInstitution(Institution institution) {
		this.institution = institution;
	}
	public Date getIssuedDate() {
		return issuedDate;
	}
	public void setIssuedDate(Date issuedDate) {
		this.issuedDate = issuedDate;
	}
	@Override
	public String toString() {
		return "Credential [Credential_Id=" + Credential_Id + ", credentialName=" + credentialName + ", credentialYear="
				+ credentialYear + ", course=" + course.getCourse_Id() + ", institution=" + institution.getInstitution_Id() + ", issuedDate=" + issuedDate
				+ "]";
	}
	
	
}
