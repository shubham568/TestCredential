package com.example.digital.service;

public interface IInstitutionService {

}
