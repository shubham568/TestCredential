package com.example.digital.repository;


import java.util.List;

import com.example.digital.entity.Contact;
import com.example.digital.entity.Institution;


public interface IInstitutionDao {

	List<Institution> getAllInstitutions();
	Institution getInstitutionByid(long institution_Id);
    void addInstitution(Institution institution);
    void updateInstitution(Institution institution);
   // void deleteInstitution(Institution institution);
    boolean institutionExists(Contact contact, long Parent_Institution_Id);
	
}
