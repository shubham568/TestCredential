package com.example.digital.entity;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
@SuppressWarnings("serial")
@Entity
@Table(name="course")
public class Course implements Serializable {

	public Course() {
		super();
	}
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="Course_Id")
	private long Course_Id;
	@Column(name="Course_Name")
	private String Course_Name;
	@Column(name="Short_Name")
	private String Short_Name;
	@Column(name="Description")
	private String Description;
	@JoinColumn(name="Institution_Id")
	@ManyToOne(targetEntity = Institution.class,fetch = FetchType.EAGER,cascade=CascadeType.ALL)
	
	private Institution institution;
	@Column(name="Course_Period")
	private String Course_Period;
	public long getCourse_Id() {
		return Course_Id;
	}
	public void setCourse_Id(long course_Id) {
		Course_Id = course_Id;
	}
	public String getCourse_Name() {
		return Course_Name;
	}
	public void setCourse_Name(String course_Name) {
		Course_Name = course_Name;
	}
	public String getShort_Name() {
		return Short_Name;
	}
	public void setShort_Name(String short_Name) {
		Short_Name = short_Name;
	}
	public String getDescription() {
		return Description;
	}
	public void setDescription(String description) {
		Description = description;
	}
	public String getCourse_Period() {
		return Course_Period;
	}
	public void setCourse_Period(String course_Period) {
		Course_Period = course_Period;
	}
	

	@Override
	public String toString() {
		return "Course  [Course_Id =" + Course_Id + "Course_Name =" + Course_Name + "Short_Name =" +Short_Name + 
				"Description" + Description + "Course_Period" + Course_Period + "Institution_Id" + institution.getInstitution_Id()+ 
				"]";
	}
}
