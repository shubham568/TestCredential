package com.example.digital.repository;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.example.digital.entity.Course;
import com.example.digital.entity.Credential;
import com.example.digital.entity.Institution;
@Transactional
@Repository
public class CredentialDao implements ICredentialDAO{

	@PersistenceContext	
	private EntityManager entityManager;
	
	@Override
	public Credential getCredentialByid(long credential_Id) {
		return entityManager.find(Credential.class, credential_Id);
	}
	@SuppressWarnings("unchecked")
	@Override
	public List<Credential> getAllCredentials() {
		String hql = "FROM Credential as cr ORDER BY cr.credential_Id DESC";
		return (List<Credential>) entityManager.createQuery(hql).getResultList();
	}	
	@Override
	public void addCredential(Credential credential) {
		entityManager.persist(credential);
	}
	
	@Override
	public void updateCredential(Credential credential) {
		
		if(credential!=null) {
		String hql="update Credential cr set cr.Credential_Name="+credential.getCredentialName()+"cr.Credential_Year"+credential.getCredentialYear()+
				"cr.Course_Id"+credential.getCourse().getCourse_Id()+"cr.Institution_Id"+credential.getInstitution().getInstitution_Id()+
				"where cr.Credential_Id="+credential.getCredential_Id();
		
		System.out.println("HQL->"+hql);
		entityManager.createQuery(hql).executeUpdate();
		}
		else {
			entityManager.remove(credential);
		}
		//entityManager.remove(getCourseByid(course_Id));
	}
	@Override
	public boolean CredentialExists(String Credential_Name, String Credential_Year,Course course,Institution institution) {
		String hql = "FROM Credential as cr WHERE cr.Credential_Name = ? and cr.Credential_Year = ? and cr.Course_Id = ? and cr.Institution_Id = ?";
		int count = entityManager.createQuery(hql).setParameter(1, Credential_Name)
		              .setParameter(2, Credential_Year).setParameter(3, course).setParameter(4, institution).getResultList().size();
		return count > 0 ? true : false;
	}
	

}
