package com.example.digital.service;

import org.springframework.stereotype.Service;

@Service
public class UserDetailsServiceImpl{ /*implements UserDetailsService{

	@Autowired
    private UserRepository userRepository;
	

    @Override
    @Transactional(readOnly = true)
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        User user = userRepository.findByUserName(username);

        Set<GrantedAuthority> grantedAuthorities = new HashSet<>();
        for (Role role : user.getRoles()){
            grantedAuthorities.add(new SimpleGrantedAuthority(role.getRole_name()));
        }

        return new org.springframework.security.core.userdetails.User(user.getUserName(), user.getPassword(), grantedAuthorities);
    }
*/
}
