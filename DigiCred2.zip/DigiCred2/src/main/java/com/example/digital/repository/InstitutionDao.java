package com.example.digital.repository;


import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.example.digital.entity.Contact;
import com.example.digital.entity.Institution;

@Transactional
@Repository
public class InstitutionDao implements IInstitutionDao {

	@PersistenceContext	
	private EntityManager entityManager;
	
	@Override
	public Institution getInstitutionByid(long institution_Id) {
		return entityManager.find(Institution.class, institution_Id);
	}
	@SuppressWarnings("unchecked")
	@Override
	public List<Institution> getAllInstitutions() {
		String hql = "FROM Institution as ins ORDER BY ins.Institution_Id DESC";
		return (List<Institution>) entityManager.createQuery(hql).getResultList();
	}	
	@Override
	public void addInstitution(Institution institution) {
		entityManager.persist(institution);
	}
	/*@Override
	public void updateInstitution(Institution institution) {
		Institution ins = getInstitutionByid(institution.getInstitution_Id());
		ins.setContact(institution.getContact().getContact_Id());
		ins.setParent_Institution_Id(institution.getParent_Institution_Id());
		entityManager.flush();
	}*/
	
	@Override
	public void updateInstitution(Institution institution) {
		String hql="update Institution ins set ins.Contact_Id="+institution.getContact().getContact_Id()+"ins.Parent_Institution_Id"+institution.getParent_Institution_Id()+
				
				"where ins.Institution_Id="+institution.getInstitution_Id();
		
		System.out.println("HQL->"+hql);
		entityManager.createQuery(hql).executeUpdate();
		
		//entityManager.remove(getInstitutionByid(Institution_Id));
	}
	@Override
	public boolean institutionExists(Contact contact, long Parent_Institution_Id) {
		String hql = "FROM Institution as ins WHERE ins.Contact_Id = ? and ins.Parent_Institution_Id = ?";
		int count = entityManager.createQuery(hql).setParameter(1, contact.getContact_Id())
		              .setParameter(2, Parent_Institution_Id).getResultList().size();
		return count > 0 ? true : false;
	}

}
