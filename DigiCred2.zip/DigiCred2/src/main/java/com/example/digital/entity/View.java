package com.example.digital.entity;

public class View {
	public interface FileInfo {}
}
