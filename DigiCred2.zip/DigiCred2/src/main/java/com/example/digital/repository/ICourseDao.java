package com.example.digital.repository;


import java.util.List;

import com.example.digital.entity.Course;


public interface ICourseDao {

	List<Course> getAllCourses();
	Course getCourseByid(long course_Id);
    void addCourse(Course course);
    void updateCourse(Course course);
    //void deleteCourse(Course course);
    boolean CourseExists(String Course_Name, String Short_Name,String Description,long Institution_Id,String Course_Period);
	
}
